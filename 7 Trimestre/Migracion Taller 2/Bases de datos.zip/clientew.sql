DROP TABLE IF EXISTS `Cliente`;

CREATE TABLE `Cliente` (
  `id` mediumint(8) unsigned NOT NULL auto_increment,
  `nombre` varchar(255) default NULL,
  `region` varchar(50) default NULL,
  `email` varchar(255) default NULL,
  PRIMARY KEY (`id`)
) AUTO_INCREMENT=1;

INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Xantha Larsen","Baja California","sodales@protonmail.ca"),
  ("Natalie Dorsey","Mazowieckie","fermentum.convallis@protonmail.ca"),
  ("Lisandra Fuentes","Xīběi","mi.fringilla.mi@protonmail.couk"),
  ("Aaron Beasley","Vestfold og Telemark","mi.fringilla.mi@icloud.ca"),
  ("Emerald Graves","South Jeolla","turpis.in.condimentum@icloud.com"),
  ("Alfreda Hudson","Glamorgan","feugiat@protonmail.org"),
  ("Demetria Kirkland","Alajuela","ut.ipsum@outlook.edu"),
  ("Colorado Riddle","North Island","nascetur.ridiculus.mus@aol.net"),
  ("Sawyer Kemp","La Libertad","odio@aol.com"),
  ("Fitzgerald Potts","North-East Region","arcu.sed@google.couk");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Mercedes Mcclure","South Chungcheong","auctor@protonmail.net"),
  ("Clare Vang","Balochistan","lacus.nulla.tincidunt@google.couk"),
  ("Inez Paul","Andaman and Nicobar Islands","in.ornare.sagittis@outlook.net"),
  ("Quemby Mcconnell","Balochistan","mi.eleifend@icloud.com"),
  ("Britanni Alston","Valparaíso","tempus@hotmail.net"),
  ("Giselle Stone","Mississippi","quisque.ac@google.org"),
  ("Mikayla Mosley","Rio de Janeiro","sociosqu.ad.litora@hotmail.ca"),
  ("Mariko Harvey","Valparaíso","condimentum.eget@hotmail.edu"),
  ("Curran Lee","Arunachal Pradesh","tincidunt.nunc@aol.net"),
  ("Boris Mack","West Lothian","scelerisque@hotmail.edu");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Rinah Luna","South Gyeongsang","orci.donec.nibh@google.edu"),
  ("Carla Hernandez","Flevoland","non.massa@icloud.ca"),
  ("Darius Bean","Lubuskie","sit.amet@google.net"),
  ("Amery Moon","Nova Scotia","rhoncus.nullam@protonmail.ca"),
  ("Dustin Terry","Vestland","nibh@aol.com"),
  ("Lucius Watkins","Leinster","ultrices.posuere@protonmail.org"),
  ("Yoko O'Neill","São Paulo","sit.amet@icloud.edu"),
  ("Clio Pugh","Innlandet","orci.adipiscing@outlook.org"),
  ("Justina Whitfield","Niedersachsen","magna@hotmail.com"),
  ("Lev Chang","Rheinland-Pfalz","vehicula.pellentesque@outlook.net");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Cameron Gallagher","Huáběi","elementum.dui@icloud.edu"),
  ("Raven Robles","Ulster","purus.in.molestie@hotmail.org"),
  ("Giacomo Butler","North Island","augue.malesuada@aol.edu"),
  ("Heidi Mann","Podkarpackie","non.hendrerit@protonmail.couk"),
  ("Frances Boyle","Cajamarca","metus.aenean@yahoo.ca"),
  ("Hope Tucker","Manitoba","adipiscing@google.net"),
  ("Brody Strickland","Västra Götalands län","etiam@yahoo.edu"),
  ("Emmanuel Dunn","Anambra","rutrum@yahoo.com"),
  ("Gabriel Schroeder","Puntarenas","cras@outlook.ca"),
  ("Jeanette Waters","Lincolnshire","magnis.dis@outlook.com");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Kiona Gill","Maule","non.feugiat.nec@yahoo.couk"),
  ("Rose Acosta","Kansas","dictum.eleifend@google.ca"),
  ("Ralph Mccarthy","Bình Thuận","non.dapibus@google.couk"),
  ("Berk Gordon","Tyrol","nec.imperdiet@hotmail.org"),
  ("Phyllis Riggs","North Jeolla","vel.faucibus.id@google.org"),
  ("Josiah Aguilar","North Region","orci.lobortis@yahoo.org"),
  ("Rebekah Smith","Irkutsk Oblast","suscipit@hotmail.com"),
  ("Lester Witt","Chihuahua","eu@protonmail.edu"),
  ("Rachel Finch","British Columbia","nibh@google.couk"),
  ("Zephr Savage","Xīnán","aliquet@outlook.org");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Scarlet Ewing","Himachal Pradesh","dolor.dapibus@icloud.org"),
  ("Todd Sloan","Maryland","nibh.donec@aol.ca"),
  ("Jakeem Park","Puntarenas","adipiscing.enim@outlook.net"),
  ("Regan Jordan","Lombardia","lectus.ante@icloud.org"),
  ("Lucian Maldonado","Nariño","cursus.et@icloud.edu"),
  ("Eleanor Reilly","Leinster","sapien.molestie@hotmail.ca"),
  ("Lydia Hurley","Xīnán","ullamcorper@yahoo.net"),
  ("Devin Garza","North Island","placerat.augue.sed@yahoo.org"),
  ("Dennis Dillon","Antwerpen","velit.sed.malesuada@aol.ca"),
  ("Russell Welch","Flevoland","pede.blandit@aol.ca");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Nasim Gordon","Free State","fusce.dolor.quam@protonmail.ca"),
  ("Patricia Bauer","Sachsen","a.aliquet@aol.couk"),
  ("Linda Gomez","Ancash","suspendisse.aliquet@icloud.edu"),
  ("Tana Figueroa","Pays de la Loire","mauris.integer.sem@icloud.org"),
  ("Heather Barber","Zamboanga Peninsula","ornare.tortor.at@yahoo.edu"),
  ("Brady Sawyer","Morelos","mi.felis@google.com"),
  ("Byron Fuentes","Trøndelag","vitae@outlook.edu"),
  ("Channing Carver","Ogun","massa.lobortis.ultrices@outlook.net"),
  ("Aspen Dale","Cesar","non.enim@protonmail.edu"),
  ("Blossom Humphrey","South Island","ut.dolor@yahoo.org");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Chaney Briggs","Puglia","et.magnis@icloud.couk"),
  ("Fleur Hull","Eastern Cape","nunc@protonmail.couk"),
  ("Julian Waters","Coquimbo","phasellus@aol.ca"),
  ("Jordan Vincent","Iowa","gravida.nunc@icloud.org"),
  ("Carlos Randall","Volyn oblast","pede.nunc@outlook.net"),
  ("Nyssa Bond","Cordillera Administrative Region","interdum.sed@aol.net"),
  ("Uriah Mercado","West Region","in@icloud.ca"),
  ("Vera Griffith","West Java","donec.nibh.quisque@google.com"),
  ("Lilah Jordan","Nevada","ac.fermentum.vel@hotmail.net"),
  ("Kiara May","South Island","phasellus.dolor@icloud.com");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Jerry Glass","Vienna","eleifend.cras.sed@outlook.ca"),
  ("Macon Schmidt","Piura","vitae.orci.phasellus@icloud.net"),
  ("Gage Valentine","Australian Capital Territory","nibh.phasellus.nulla@hotmail.ca"),
  ("Alana Roach","Northern Territory","aliquet.odio@protonmail.edu"),
  ("Sean Weiss","Samsun","aenean.eget@protonmail.org"),
  ("Cassady Gibson","Lubelskie","proin.vel@google.org"),
  ("Cora Houston","Balochistan","mattis.velit@protonmail.ca"),
  ("Nicholas Boone","Herefordshire","id.mollis@outlook.edu"),
  ("Nolan Stevens","Coahuila","mus.donec.dignissim@outlook.org"),
  ("Liberty Woodard","Alajuela","cras.dolor@google.com");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Thane Moss","Eastern Cape","vitae.sodales.at@yahoo.couk"),
  ("Gwendolyn Jackson","Oaxaca","vestibulum.massa@icloud.org"),
  ("Evan Boyd","Gauteng","interdum.enim@outlook.couk"),
  ("Karen Morrison","Volyn oblast","auctor.nunc@google.net"),
  ("Lee French","Ivano-Frankivsk oblast","malesuada@icloud.net"),
  ("Dorothy Moran","Kogi","cursus.non@aol.com"),
  ("Reed Mathis","Guanacaste","sed.dictum@google.org"),
  ("Jenette Conley","Xīběi","faucibus.ut.nulla@yahoo.com"),
  ("Myra Mcdonald","Midlothian","amet.consectetuer@yahoo.edu"),
  ("Anika Thornton","Imo","consectetuer.rhoncus@aol.couk");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Drew Bonner","Saratov Oblast","cursus@google.couk"),
  ("Lee Mullen","Burgenland","dapibus.ligula@protonmail.ca"),
  ("Caleb Bonner","Khmelnytskyi oblast","etiam.gravida@protonmail.net"),
  ("Bruce Simmons","Bremen","facilisis.vitae@yahoo.couk"),
  ("Camilla Mcknight","Volyn oblast","praesent.eu@yahoo.com"),
  ("Charissa Allison","Lower Austria","enim.sed.nulla@hotmail.couk"),
  ("Quin Huber","Gelderland","dui.quis@aol.ca"),
  ("Knox England","Durham","purus.nullam@hotmail.edu"),
  ("Rigel Melton","Gangwon","felis@yahoo.com"),
  ("Sean Kim","Champagne-Ardenne","nec.imperdiet.nec@aol.com");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Veda Sanchez","North-East Region","morbi.metus@hotmail.edu"),
  ("Hannah Sweet","Nova Scotia","interdum.curabitur@hotmail.couk"),
  ("Baxter Clarke","Bình Thuận","nibh.vulputate.mauris@outlook.org"),
  ("Carlos Boone","Bryansk Oblast","adipiscing@outlook.edu"),
  ("Lani Cooper","Jigawa","interdum.feugiat@icloud.net"),
  ("Nevada Justice","South Gyeongsang","non.lobortis@protonmail.couk"),
  ("Stephen Madden","Sutherland","malesuada.malesuada@yahoo.ca"),
  ("Mia Fuller","South Chungcheong","arcu.et@outlook.couk"),
  ("Karly Alvarez","Huádōng","eu.metus.in@google.edu"),
  ("Cody Whitaker","Nairnshire","velit@icloud.edu");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Rina Sims","Saskatchewan","sed.et@outlook.ca"),
  ("Todd Conway","Västra Götalands län","lorem@protonmail.couk"),
  ("Geraldine Calhoun","New Brunswick","posuere.cubilia@yahoo.com"),
  ("Jordan Aguilar","Saskatchewan","ac.arcu@outlook.org"),
  ("Caesar Jimenez","Huáběi","netus.et.malesuada@yahoo.couk"),
  ("Kitra Vega","South Island","aliquam.ornare.libero@icloud.com"),
  ("Jessamine Ochoa","Kerala","ornare.tortor@protonmail.ca"),
  ("Armando Gilbert","East Region","cras@yahoo.net"),
  ("Joseph Atkins","Zeeland","habitant.morbi@outlook.net"),
  ("Jocelyn Dyer","Goiás","dolor.dolor@outlook.couk");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Marsden Houston","Punjab","arcu.ac@icloud.net"),
  ("Kylee Richmond","Navarra","orci.luctus@hotmail.couk"),
  ("Marny Nieves","Manisa","euismod@aol.couk"),
  ("Penelope Blevins","Northwest Territories","dis.parturient@hotmail.net"),
  ("Patience Montgomery","Heredia","dolor@aol.org"),
  ("Austin Lancaster","Quebec","pretium.aliquet@yahoo.net"),
  ("Noel Erickson","Upper Austria","libero.dui@protonmail.edu"),
  ("May Valencia","Đắk Lắk","dui.quis@icloud.edu"),
  ("Imani Fowler","Surrey","metus.in@google.ca"),
  ("Reuben Wiley","Basse-Normandie","at.libero@hotmail.net");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Sybill Rasmussen","Florida","odio@aol.com"),
  ("Lesley Douglas","Puno","a.mi@yahoo.edu"),
  ("Chester Burks","Västra Götalands län","cursus.purus@aol.couk"),
  ("Bethany Reed","Sinaloa","integer.vulputate@aol.ca"),
  ("Portia Odom","Huáběi","montes.nascetur@protonmail.org"),
  ("Molly Moody","Special Region of Yogyakarta","et.malesuada@protonmail.net"),
  ("Cathleen Mckee","Vestfold og Telemark","augue.ac@outlook.com"),
  ("Richard Trevino","Oyo","mollis.duis.sit@aol.edu"),
  ("Adria Fulton","Los Lagos","consequat.purus.maecenas@hotmail.couk"),
  ("Halla James","Xīnán","dignissim.magna.a@icloud.edu");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Dora Carr","Norte de Santander","ornare@hotmail.com"),
  ("Adrienne Schmidt","Arizona","nunc.sollicitudin@yahoo.edu"),
  ("Tallulah Cantu","Chandigarh","at.augue.id@aol.org"),
  ("Shelly Benjamin","Alajuela","aliquet.sem.ut@google.couk"),
  ("Maite Burgess","Bursa","orci.adipiscing.non@yahoo.couk"),
  ("Zoe Sawyer","Utrecht","dolor.quisque@hotmail.couk"),
  ("Kieran Bush","Cartago","accumsan.sed@outlook.edu"),
  ("Kylan Terrell","Castilla y León","lacus.quisque@outlook.com"),
  ("Grace Rocha","Magdalena","hendrerit.neque@icloud.org"),
  ("Omar Gibson","South Jeolla","non.arcu@aol.com");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Kaye Fox","Bengkulu","pellentesque.ut@yahoo.ca"),
  ("Baker Drake","Iowa","et.arcu.imperdiet@protonmail.net"),
  ("Olivia Parker","Mpumalanga","elit@yahoo.org"),
  ("Roanna Molina","Osun","nullam.enim.sed@aol.org"),
  ("Caleb Griffin","Drenthe","penatibus.et@aol.com"),
  ("Laurel Herring","Gangwon","nulla.at@icloud.edu"),
  ("Haley Preston","Rogaland","quisque.porttitor@aol.edu"),
  ("Michelle Thornton","Goiás","magna.malesuada@aol.net"),
  ("Sasha Houston","Schleswig-Holstein","nulla.integer@outlook.couk"),
  ("Beau Parrish","Central Java","vehicula.et@protonmail.couk");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Devin Hooper","Maule","quis.lectus@aol.org"),
  ("Sandra Frederick","Konya","egestas.urna@protonmail.org"),
  ("Hunter Ball","Pernambuco","aliquam.tincidunt.nunc@yahoo.net"),
  ("Gray Chapman","Antwerpen","nec.ante@outlook.com"),
  ("Dale Gallagher","Goiás","nunc.pulvinar@hotmail.net"),
  ("Hyatt Pittman","Sardegna","ligula@icloud.couk"),
  ("MacKenzie Wagner","Pomorskie","enim.consequat@hotmail.net"),
  ("Christopher Howe","West-Vlaanderen","aliquam.fringilla@yahoo.couk"),
  ("Armand Herrera","Sląskie","penatibus.et@icloud.org"),
  ("Keiko Parrish","Castilla y León","consequat@yahoo.org");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Judah Bowen","Zhōngnán","felis.purus@yahoo.org"),
  ("Sawyer Potts","Akwa Ibom","dui@yahoo.com"),
  ("Raphael Petty","Dōngběi","ipsum.dolor.sit@aol.ca"),
  ("Leandra Hester","Mecklenburg-Vorpommern","sit.amet.orci@google.org"),
  ("Rowan Hodges","San José","mattis.semper.dui@icloud.ca"),
  ("Hermione Rojas","Western Australia","luctus.sit@icloud.org"),
  ("Vera Christian","Manisa","elit.pharetra.ut@yahoo.net"),
  ("Gannon Stout","Benue","fringilla.cursus.purus@google.net"),
  ("Tarik Knapp","Rio Grande do Sul","cursus@aol.org"),
  ("Thane Dillard","Maine","ultrices.a@aol.net");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Fredericka Fletcher","Castilla - La Mancha","sit@hotmail.net"),
  ("Reuben Santana","Dalarnas län","tincidunt@outlook.ca"),
  ("Brielle Alford","West Region","risus.nunc@hotmail.net"),
  ("Medge Compton","Auvergne","nonummy@hotmail.com"),
  ("Justina Burgess","Prince Edward Island","eu.tempor@aol.ca"),
  ("Jarrod Donovan","Molise","curabitur.dictum@yahoo.ca"),
  ("Hyacinth Long","Pomorskie","cras.eu@icloud.com"),
  ("Joshua Madden","Brandenburg","est@yahoo.edu"),
  ("Harriet Harrington","Kent","cursus.purus@protonmail.net"),
  ("Gabriel Maldonado","Zhytomyr oblast","nec@icloud.couk");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Winter Marsh","Pará","velit.dui.semper@hotmail.net"),
  ("Raymond Ferrell","Arequipa","felis.donec@yahoo.edu"),
  ("Lewis Mathis","Bryansk Oblast","enim@google.net"),
  ("Uriah Clarke","Sachsen-Anhalt","sem.magna.nec@icloud.ca"),
  ("Lawrence Warren","La Libertad","orci@aol.org"),
  ("Laith Head","Goiás","lorem.eget@icloud.edu"),
  ("Whoopi Lester","Pomorskie","quis.diam.pellentesque@protonmail.ca"),
  ("Fatima Sullivan","Overijssel","montes.nascetur.ridiculus@icloud.edu"),
  ("Yvonne Berger","Haute-Normandie","et.netus@google.ca"),
  ("Driscoll Hart","Zhōngnán","vulputate.lacus@hotmail.couk");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Andrew Morse","Maule","id@outlook.net"),
  ("Celeste Winters","Atacama","fringilla.ornare@hotmail.com"),
  ("Cameron O'connor","Lazio","consequat.auctor@aol.ca"),
  ("Mara Griffin","Gaziantep","mollis.duis@icloud.ca"),
  ("Merrill Dyer","Hậu Giang","dis.parturient@aol.net"),
  ("Lacey Snow","Ulster","et.malesuada@outlook.com"),
  ("Herrod Barnett","Mazowieckie","vivamus.euismod@aol.com"),
  ("Drew Miranda","Northern Cape","elit.curabitur@outlook.org"),
  ("Ross Gamble","İzmir","phasellus.dapibus.quam@aol.couk"),
  ("Kelsie Smith","Buckinghamshire","euismod.urna@aol.com");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Ivana Chaney","Prince Edward Island","ultricies.dignissim@yahoo.edu"),
  ("Moses Strickland","Hà Giang","dolor.donec@outlook.edu"),
  ("Ira Duke","Tamaulipas","convallis@protonmail.ca"),
  ("Leandra Winters","Magadan Oblast","justo@google.com"),
  ("Mufutau Nieves","Hậu Giang","dictum@icloud.ca"),
  ("William Dudley","Worcestershire","nec.urna@icloud.couk"),
  ("Roanna Walker","Antioquia","non.lorem@google.ca"),
  ("Tatyana Carson","Hà Tĩnh","amet@yahoo.net"),
  ("Hall Lloyd","South Jeolla","non.massa@outlook.ca"),
  ("Allistair Ford","Tamil Nadu","eget.metus.in@yahoo.couk");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Jacqueline Dillon","Saskatchewan","a@aol.org"),
  ("Vincent Melton","Zakarpattia oblast","donec@icloud.com"),
  ("Marsden Camacho","Haryana","dui.nec@protonmail.org"),
  ("Jade Dalton","Dalarnas län","felis@icloud.net"),
  ("Jackson Torres","North Island","tincidunt.adipiscing@google.net"),
  ("Laura Fields","Viken","facilisis.facilisis@google.com"),
  ("Kirestin Lott","North Region","enim.nisl@google.ca"),
  ("Joy Macias","Bình Định","nunc.sed@google.com"),
  ("Reuben Merritt","Vĩnh Phúc","viverra@protonmail.couk"),
  ("Karyn Guy","Davao Region","et@hotmail.net");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Kasper Austin","Oslo","faucibus.orci@aol.org"),
  ("Calvin Leonard","Lower Austria","blandit.viverra@aol.net"),
  ("Iliana Patrick","Jalisco","risus.nunc@outlook.net"),
  ("Rylee Campos","New Brunswick","ante@google.edu"),
  ("Eugenia Pugh","Lower Austria","sed@hotmail.couk"),
  ("Aurora Cabrera","Mersin","nulla.tincidunt.neque@hotmail.ca"),
  ("Libby Salas","Västra Götalands län","inceptos.hymenaeos@google.couk"),
  ("Nigel Morris","Centre","massa@icloud.couk"),
  ("Barry Pennington","Puntarenas","turpis@yahoo.edu"),
  ("Inez Beard","Hải Dương","a.ultricies.adipiscing@yahoo.org");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Cadman Golden","Argyllshire","nascetur@hotmail.org"),
  ("Madonna Jackson","North Island","dui.cras.pellentesque@google.com"),
  ("Aidan Battle","Kincardineshire","ante.dictum@yahoo.edu"),
  ("Athena Mcgee","Dalarnas län","nulla@hotmail.couk"),
  ("Isabelle Olson","Central Region","purus.duis@icloud.com"),
  ("Reuben Carr","La Guajira","lacinia@icloud.net"),
  ("Wang Pope","Borno","imperdiet.dictum@icloud.net"),
  ("Blake Hoffman","Dalarnas län","euismod@google.ca"),
  ("Alvin Nieves","Nova Scotia","tellus@hotmail.couk"),
  ("Clinton Reilly","Burgenland","dui.lectus.rutrum@yahoo.couk");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Jade Delacruz","South Island","mollis.vitae@outlook.com"),
  ("Ulla Richardson","Amur Oblast","vel.pede.blandit@aol.ca"),
  ("Mark Murray","Limburg","scelerisque.dui.suspendisse@google.couk"),
  ("Alexis Schmidt","Western Visayas","integer.in@hotmail.net"),
  ("Allen Harper","Bretagne","cursus@icloud.org"),
  ("Clayton Floyd","Xīběi","scelerisque.sed@hotmail.com"),
  ("Cara Schmidt","Auvergne","elit.erat@aol.ca"),
  ("Derek Brooks","Heredia","nunc.sit@protonmail.edu"),
  ("Chancellor Hutchinson","Rivne oblast","nonummy@protonmail.net"),
  ("Madeson Emerson","Osun","non@outlook.ca");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Francis Watkins","Lạng Sơn","neque@google.net"),
  ("Ronan Middleton","Kano","iaculis.odio.nam@outlook.org"),
  ("Olga Castillo","Västra Götalands län","integer@aol.couk"),
  ("Aimee Rosa","Massachusetts","ornare@icloud.com"),
  ("Merritt Irwin","Vienna","risus.duis@yahoo.net"),
  ("Nola Vaughn","Iowa","vestibulum.ut@yahoo.com"),
  ("Fallon Best","West Java","quis.pede.suspendisse@icloud.net"),
  ("Meghan Sloan","Hamburg","et.arcu@protonmail.net"),
  ("Jeremy Herrera","Stockholms län","justo.sit.amet@hotmail.couk"),
  ("Rose Shannon","Lubelskie","gravida.molestie@aol.edu");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Leila Peters","South Island","magna.sed@protonmail.ca"),
  ("Sybill Beach","Podkarpackie","consectetuer@hotmail.com"),
  ("Nigel Lamb","Lambayeque","facilisis.suspendisse@hotmail.ca"),
  ("Leo Serrano","Nordland","cras.eu.tellus@google.net"),
  ("Malcolm Gonzales","Rio Grande do Sul","eros@aol.couk"),
  ("Paul Hunter","Oryol Oblast","velit.pellentesque@yahoo.ca"),
  ("Aretha Guy","Staffordshire","a.mi.fringilla@outlook.com"),
  ("Ian Castillo","South Kalimantan","adipiscing@google.com"),
  ("Chloe Farmer","South Jeolla","vitae.posuere@outlook.ca"),
  ("Kevin Elliott","Dnipropetrovsk oblast","sapien@aol.couk");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Chava Adkins","Overijssel","lobortis.ultrices.vivamus@outlook.org"),
  ("Gregory Tran","Ulster","mauris@outlook.ca"),
  ("Herman Reed","Cornwall","ac.arcu@outlook.com"),
  ("David Newton","Stockholms län","amet.ante@aol.edu"),
  ("Paula Harrell","Xīběi","turpis.egestas@icloud.org"),
  ("Lael Farmer","South Chungcheong","sed@google.edu"),
  ("Yeo Saunders","Zhōngnán","magna.lorem@aol.couk"),
  ("Nigel Gilbert","Nord-Pas-de-Calais","in.ornare.sagittis@yahoo.com"),
  ("Vaughan Ramos","Azad Kashmir","ullamcorper.duis.cursus@hotmail.edu"),
  ("Chloe Wolf","Long An","lacinia.sed.congue@google.edu");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Zeus Estes","Samara Oblast","dui.augue.eu@google.net"),
  ("Keane Barron","Manisa","ipsum.dolor@yahoo.ca"),
  ("Hu Wall","Sverdlovsk Oblast","accumsan.sed.facilisis@icloud.org"),
  ("Calista Kirby","West Region","orci.lacus@icloud.edu"),
  ("Malik Mathis","Khyber Pakhtoonkhwa","orci@outlook.couk"),
  ("Chiquita Berg","Cusco","aliquam.gravida@icloud.net"),
  ("Gage Melton","North-East Region","ipsum.suspendisse@icloud.com"),
  ("Raphael Cline","Loreto","sagittis.augue@hotmail.org"),
  ("Troy Steele","Hà Tĩnh","ornare.facilisis@hotmail.couk"),
  ("Alyssa Juarez","Borno","fermentum.vel@protonmail.edu");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Oleg Stout","Bicol Region","a.magna@google.org"),
  ("Dolan Schroeder","Azad Kashmir","lectus.nullam.suscipit@yahoo.couk"),
  ("Mohammad Hoover","Overijssel","nulla.cras.eu@protonmail.com"),
  ("Iona Mccullough","Bạc Liêu","taciti.sociosqu@outlook.org"),
  ("Kelly Gonzales","Noord Holland","orci.adipiscing.non@protonmail.couk"),
  ("Colt Chandler","Central Region","id.libero@outlook.com"),
  ("Daniel Reed","Huádōng","cras.dolor@icloud.com"),
  ("Dahlia Cochran","KwaZulu-Natal","nulla@hotmail.edu"),
  ("Kevin Farley","Jammu and Kashmir","ipsum.dolor@yahoo.ca"),
  ("Elijah Guy","Sumy oblast","nisl.sem@yahoo.net");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Virginia Patton","Volyn oblast","nec.euismod@outlook.net"),
  ("Lani Todd","Sindh","nisl.sem.consequat@aol.com"),
  ("Driscoll Nolan","Maule","risus.nunc@hotmail.edu"),
  ("Troy Graham","Niedersachsen","diam.dictum.sapien@hotmail.net"),
  ("Lani Ratliff","Connacht","pellentesque.massa@icloud.ca"),
  ("Lucas Parker","Khyber Pakhtoonkhwa","facilisis.suspendisse@hotmail.com"),
  ("Lionel Rutledge","Xīnán","vitae.purus@hotmail.couk"),
  ("Michelle Howe","Gilgit Baltistan","at@yahoo.couk"),
  ("Denise Best","Jönköpings län","erat@aol.couk"),
  ("Nerea Pruitt","Tabasco","non.dapibus@hotmail.org");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Yoshio Brewer","Sucre","cursus.purus@protonmail.net"),
  ("Rylee Fields","North Kalimantan","in.tincidunt@protonmail.couk"),
  ("Cheryl Levy","Northern Cape","dolor.tempus.non@icloud.ca"),
  ("Xavier Talley","Cajamarca","posuere@google.net"),
  ("Yoshio Calhoun","Leinster","ut@yahoo.edu"),
  ("Camden Tyson","Kherson oblast","rhoncus@outlook.ca"),
  ("Karly Hinton","Central Sulawesi","facilisi.sed@outlook.com"),
  ("Vera Woodard","Nghệ An","lorem.vitae@outlook.org"),
  ("Carol Contreras","Connacht","et@icloud.couk"),
  ("Garth Preston","Chernivtsi oblast","integer.vitae.nibh@aol.org");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Dennis Little","San José","nec.tempus@hotmail.com"),
  ("Darrel Lambert","Hòa Bình","enim.mi@google.ca"),
  ("Wynne Riggs","Essex","est.tempor@protonmail.edu"),
  ("Nevada Salas","Antwerpen","lobortis.augue.scelerisque@yahoo.edu"),
  ("Autumn Burke","Leinster","nulla.integer.urna@protonmail.edu"),
  ("Kadeem Bradshaw","Puno","interdum@yahoo.com"),
  ("Clayton Pearson","Nordrhein-Westphalen","at.fringilla@outlook.edu"),
  ("Ila Taylor","Ankara","donec.tempor@google.couk"),
  ("Zoe Silva","Atacama","massa.non@yahoo.couk"),
  ("Christian Emerson","Eastern Visayas","aenean.gravida@aol.com");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Sharon Tate","Brandenburg","nunc.sed.orci@protonmail.couk"),
  ("Hyacinth Stephens","Munster","nulla@outlook.net"),
  ("Ainsley Porter","Arequipa","lorem.ac@hotmail.edu"),
  ("Rashad Medina","Newfoundland and Labrador","fermentum.fermentum@aol.org"),
  ("Hillary Ellison","Munster","sem.semper.erat@aol.ca"),
  ("Sacha Bowman","Lagos","lorem.ut.aliquam@yahoo.net"),
  ("Leo Osborn","Tambov Oblast","turpis.in.condimentum@outlook.edu"),
  ("Ryder Martin","Ceuta","vulputate.posuere.vulputate@yahoo.edu"),
  ("Quon Maynard","Coquimbo","massa.suspendisse@icloud.com"),
  ("Astra Reed","Arauca","dui.nec@outlook.ca");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Jemima Mckay","Salzburg","a@yahoo.org"),
  ("Benedict Camacho","Innlandet","urna.nec@hotmail.com"),
  ("Adam Ashley","Karnataka","vulputate.ullamcorper.magna@google.edu"),
  ("Kimberley Farmer","Katsina","ridiculus.mus.donec@yahoo.org"),
  ("Astra Leblanc","Munster","quam.vel.sapien@icloud.net"),
  ("Daria Singleton","Sachsen-Anhalt","non.enim@hotmail.org"),
  ("Colton Woodard","Kherson oblast","diam.vel.arcu@outlook.edu"),
  ("Nell Clemons","Friuli-Venezia Giulia","massa@outlook.edu"),
  ("Fletcher Torres","Rio de Janeiro","enim@aol.org"),
  ("Aphrodite Hodge","Connacht","libero.dui@aol.couk");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Mikayla Watts","Balıkesir","nec.enim.nunc@outlook.com"),
  ("Vivien Gentry","North Island","enim.nisl@protonmail.edu"),
  ("Erich Roberson","Connacht","nibh.enim.gravida@protonmail.net"),
  ("Darryl Sharpe","Bahia","malesuada.fames@protonmail.edu"),
  ("Ivor Evans","Central Region","arcu.vestibulum@icloud.edu"),
  ("Yardley Bray","Sucre","lorem.ipsum@icloud.ca"),
  ("Harding Shaffer","Sơn La","egestas.a@outlook.ca"),
  ("Lareina Blackwell","Papua","orci.sem@hotmail.org"),
  ("Quinlan Sullivan","Đắk Nông","lacinia.at.iaculis@protonmail.couk"),
  ("Cody Huber","North Island","pede.malesuada.vel@icloud.couk");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Edan Carlson","Ilocos Region","sed.dui.fusce@google.ca"),
  ("Fatima Burks","Uttar Pradesh","nibh.vulputate@hotmail.com"),
  ("Karen Diaz","Lambayeque","vel.arcu.eu@aol.couk"),
  ("Jasmine Witt","North-East Region","semper.et@yahoo.org"),
  ("Germaine Wright","North-East Region","libero.morbi@hotmail.net"),
  ("Philip Rutledge","Kayseri","orci.lacus@google.com"),
  ("Virginia Mercer","Ontario","pede.blandit@icloud.couk"),
  ("Lane Pennington","Manisa","ornare@outlook.org"),
  ("Nerea Wilkerson","Huáběi","neque.non.quam@icloud.com"),
  ("Erasmus Luna","Mississippi","malesuada@aol.ca");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Theodore Sheppard","Brussels Hoofdstedelijk Gewest","accumsan.laoreet@aol.org"),
  ("Miranda Hayden","Auvergne","eu.turpis.nulla@yahoo.net"),
  ("Lane Mayo","North Jeolla","dignissim@yahoo.org"),
  ("Yetta Stanton","Leinster","nunc.est@aol.edu"),
  ("Brielle Head","Rheinland-Pfalz","sed.diam.lorem@google.ca"),
  ("Arden Ramirez","Bursa","mauris.ut@yahoo.org"),
  ("Pearl Key","South Island","aliquet.diam@icloud.com"),
  ("Amaya Frost","Manipur","sed.dui@hotmail.org"),
  ("Risa Beasley","Istanbul","lorem.ipsum@google.com"),
  ("Kasimir Stafford","Soccsksargen","nec.euismod@protonmail.com");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Harlan West","Azad Kashmir","etiam.laoreet.libero@icloud.ca"),
  ("Mona Richard","Soccsksargen","odio.etiam@aol.ca"),
  ("Odysseus Collins","Leinster","id.ante@aol.com"),
  ("Fletcher Carrillo","Nova Scotia","orci.adipiscing.non@yahoo.couk"),
  ("Sandra Lancaster","Balıkesir","urna@hotmail.ca"),
  ("Hammett Drake","Ulyanovsk Oblast","sed.pede.cum@google.org"),
  ("Jerome Summers","Lorraine","diam@aol.org"),
  ("Stephen Avery","Vienna","gravida@yahoo.org"),
  ("Rajah Barlow","KwaZulu-Natal","egestas@outlook.couk"),
  ("Lareina Kelley","Kocaeli","aliquet.proin@outlook.org");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Sean Hayden","Vorarlberg","sem@yahoo.couk"),
  ("Geraldine Oneil","North Gyeongsang","ipsum.sodales@hotmail.org"),
  ("Wallace Mckee","Berlin","laoreet.ipsum.curabitur@protonmail.couk"),
  ("Alden Farrell","Rogaland","eu.metus@outlook.couk"),
  ("Jade Anderson","North Island","varius@google.couk"),
  ("Michelle Schroeder","North Jeolla","class.aptent@icloud.com"),
  ("Felix Barker","Thái Bình","eget.lacus@hotmail.edu"),
  ("Finn Hahn","South Jeolla","aliquet.diam@hotmail.ca"),
  ("Scott Graves","Odisha","faucibus.leo@aol.couk"),
  ("Kalia Howell","Manitoba","augue.id@aol.net");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Eagan Holman","Michoacán","nam.tempor@google.edu"),
  ("Shaeleigh Cunningham","Nizhny Novgorod Oblast","elit@yahoo.net"),
  ("Chantale Goodman","Zhytomyr oblast","massa.integer@icloud.ca"),
  ("Wallace Baird","La Rioja","mauris.elit@hotmail.org"),
  ("Jessica Arnold","Long An","donec.felis.orci@outlook.org"),
  ("Logan York","North Sulawesi","enim@hotmail.couk"),
  ("Lucas Kramer","Cornwall","ridiculus@protonmail.ca"),
  ("Ulysses Abbott","West Region","sollicitudin.adipiscing@outlook.org"),
  ("Jermaine Carver","Aceh","faucibus.id@hotmail.edu"),
  ("Kaye Love","North Jeolla","sed.congue@protonmail.net");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Laith Landry","Luxemburg","leo.cras@protonmail.com"),
  ("McKenzie Wallace","Delta","lobortis@aol.net"),
  ("Lydia Combs","Rostov Oblast","massa@aol.com"),
  ("Geoffrey Glover","Lampung","velit.eu.sem@icloud.com"),
  ("Sopoline Lynn","North Chungcheong","dignissim.tempor@google.couk"),
  ("Ahmed Cantrell","East Region","nullam.scelerisque@icloud.org"),
  ("Odette Barron","Khmelnytskyi oblast","penatibus.et@yahoo.com"),
  ("Neville Ferguson","New Brunswick","curabitur.dictum@icloud.couk"),
  ("Blake Leonard","South Island","bibendum.fermentum.metus@protonmail.net"),
  ("Vincent Barlow","Principado de Asturias","sed@google.net");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Chaim Wagner","Sindh","primis@outlook.ca"),
  ("Jasmine Goodman","Podkarpackie","facilisis.lorem@aol.ca"),
  ("Victor Lindsey","Burgenland","elit@google.com"),
  ("Lana Holt","South Australia","non.magna@yahoo.edu"),
  ("Carter Mccall","Sevastopol City","quis.diam.pellentesque@aol.edu"),
  ("Linus Hebert","Troms og Finnmark","pharetra@icloud.couk"),
  ("Montana Harrell","Eastern Cape","egestas.aliquam.fringilla@protonmail.com"),
  ("Neil Mcbride","Viken","non.sollicitudin@hotmail.com"),
  ("Noelani Foreman","Agder","mus.aenean@google.ca"),
  ("Quon Medina","Azad Kashmir","mollis.non.cursus@protonmail.ca");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Dean Underwood","Zuid Holland","ante.ipsum@hotmail.ca"),
  ("Stuart Goodman","West Region","vel.est@protonmail.couk"),
  ("Karina Nguyen","Maranhão","non.dui@aol.com"),
  ("Nola Mcmillan","Alberta","a.odio.semper@outlook.org"),
  ("Fitzgerald O'Neill","Northern Territory","non.lacinia@yahoo.edu"),
  ("Ursa Bray","Calabarzon","mi@hotmail.org"),
  ("Adena Greer","Lima","volutpat.nunc.sit@icloud.net"),
  ("Garrison Maxwell","Podkarpackie","nunc.interdum.feugiat@google.net"),
  ("May Benson","Westmorland","amet.dapibus.id@icloud.com"),
  ("Zia Bird","Rogaland","congue.turpis.in@aol.com");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Colleen House","Dadra and Nagar Haveli","fames.ac.turpis@protonmail.couk"),
  ("Sybil Clark","Virginia","eget.metus@outlook.com"),
  ("Nissim Franks","Dalarnas län","montes.nascetur.ridiculus@yahoo.couk"),
  ("Callum Leonard","Bicol Region","magna.sed@hotmail.ca"),
  ("Brenden Nixon","Bretagne","mauris.blandit@aol.com"),
  ("Helen Merrill","Colorado","et.netus@yahoo.edu"),
  ("Yasir Drake","Carinthia","aliquam.enim.nec@protonmail.com"),
  ("Edan Wiggins","Kentucky","proin.vel@icloud.edu"),
  ("Reuben Goodman","Guanacaste","ut.tincidunt@google.org"),
  ("Idona Vega","Vlaams-Brabant","tempus@protonmail.org");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Anastasia Calhoun","Ulster","lectus.pede@aol.org"),
  ("Allegra Graham","Gauteng","nam.interdum@google.edu"),
  ("Sean Campos","Arizona","feugiat.non@hotmail.com"),
  ("Cadman Harvey","Alajuela","in.cursus.et@google.org"),
  ("Asher Cohen","Luxemburg","lacus.mauris@protonmail.edu"),
  ("Idona Norton","Małopolskie","posuere@yahoo.net"),
  ("Cody Black","Lubelskie","ridiculus.mus@yahoo.org"),
  ("Mollie Bright","Ilocos Region","hendrerit@hotmail.edu"),
  ("Herrod Sweeney","Dadra and Nagar Haveli","lacinia.vitae@icloud.org"),
  ("Troy Schneider","South Island","etiam.ligula.tortor@aol.ca");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Hermione Cochran","Nghệ An","neque@google.ca"),
  ("Xaviera Russell","South Jeolla","consequat.enim.diam@hotmail.couk"),
  ("Travis Gonzales","Picardie","velit@aol.edu"),
  ("Hermione Espinoza","Huádōng","felis@aol.couk"),
  ("Kristen Stein","Jigawa","lobortis.quis@icloud.ca"),
  ("Levi Richardson","Lubelskie","et@aol.edu"),
  ("Shaeleigh Cohen","Atacama","sed.neque.sed@yahoo.edu"),
  ("Neville Head","Brussels Hoofdstedelijk Gewest","cursus.et.eros@yahoo.edu"),
  ("Echo Blake","Madhya Pradesh","tristique.neque.venenatis@protonmail.ca"),
  ("Herrod Fowler","Morelos","ante@yahoo.net");
INSERT INTO `Cliente` (`nombre`,`region`,`email`)
VALUES
  ("Simone Andrews","Agder","sodales.purus@outlook.org"),
  ("Ethan Sargent","Connacht","nam@yahoo.net"),
  ("Yasir Sharpe","Kent","vestibulum.accumsan.neque@hotmail.ca"),
  ("Carolyn Sexton","Vinnytsia oblast","libero.morbi@hotmail.net"),
  ("Shaeleigh Figueroa","Namen","et.nunc@protonmail.edu"),
  ("Shad Peck","North West","tellus.suspendisse@google.com"),
  ("Giacomo Stevenson","Vĩnh Phúc","diam.pellentesque.habitant@protonmail.org"),
  ("Kennedy Matthews","Mississippi","curabitur.sed.tortor@protonmail.net"),
  ("Cody Mccall","New South Wales","posuere.cubilia.curae@outlook.ca"),
  ("Brielle Tyler","Jönköpings län","in.at@outlook.net");
